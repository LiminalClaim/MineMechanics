<?php
header('Content-Type: application/json');

/* ================= CONFIG ================= */


define('SUPABASE_URL', 'https://vrgrmqrhrwkltopjwlrr.supabase.co');

define('SUPABASE_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZyZ3JtcXJocndrbHRvcGp3bHJyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUwODQxODUsImV4cCI6MjA4MDY2MDE4NX0.6cffp0njkFx1zzfp1PT5s29oNlg2WXoNH8ZsBx2qvz0');

define('SUPABASE_SECRET', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZyZ3JtcXJocndrbHRvcGp3bHJyIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2NTA4NDE4NSwiZXhwIjoyMDgwNjYwMTg1fQ.8VeeaMPbjUkffiHizrwJBVlLE028R2y2QOAkV9O5gXA');


/* ================= READ PAYLOAD ================= */

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

/*
Expected OxaPay fields (important ones):
status = paid
order_id
txid
amount
*/
$status   = $data['status'] ?? null;
$orderId  = $data['order_id'] ?? null;
$txid     = $data['txid'] ?? null;

if ($status !== 'paid' || !$orderId) {
    echo json_encode(['msg' => 'Ignored']);
    exit;
}

/* ================= FETCH TOPUP ================= */

$ch = curl_init(SUPABASE_URL . "/rest/v1/topups?order_id=eq.$orderId&limit=1");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'apikey: ' . SUPABASE_SECRET,
        'Authorization: Bearer ' . SUPABASE_SECRET
    ]
]);

$response = curl_exec($ch);
curl_close($ch);

$topups = json_decode($response, true);

if (!$topups || empty($topups)) {
    http_response_code(404);
    echo json_encode(['error' => 'Topup not found']);
    exit;
}

$topup = $topups[0];

/* ================= PREVENT DOUBLE CREDIT ================= */

if ($topup['status'] === 'completed') {
    echo json_encode(['msg' => 'Already processed']);
    exit;
}

$userId = $topup['user_id'];
$minem  = $topup['amount_minem'];

/* ================= UPDATE BALANCE ================= */

$balanceUpdate = [
    "minem" => $minem
];

$ch = curl_init(SUPABASE_URL . "/rest/v1/balances?user_id=eq.$userId");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CUSTOMREQUEST => 'PATCH',
    CURLOPT_HTTPHEADER => [
        'apikey: ' . SUPABASE_SECRET,
        'Authorization: Bearer ' . SUPABASE_SECRET,
        'Content-Type: application/json',
        'Prefer: resolution=merge-duplicates'
    ],
    CURLOPT_POSTFIELDS => json_encode([
        "minem" => $topup['amount_minem']
    ])
]);

curl_exec($ch);
curl_close($ch);

/* ================= MARK TOPUP COMPLETED ================= */

$ch = curl_init(SUPABASE_URL . "/rest/v1/topups?order_id=eq.$orderId");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CUSTOMREQUEST => 'PATCH',
    CURLOPT_HTTPHEADER => [
        'apikey: ' . SUPABASE_SECRET,
        'Authorization: Bearer ' . SUPABASE_SECRET,
        'Content-Type: application/json'
    ],
    CURLOPT_POSTFIELDS => json_encode([
        "status" => "completed",
        "transaction_id" => $txid,
        "updated_at" => date('c')
    ])
]);

curl_exec($ch);
curl_close($ch);

/* ================= DONE ================= */

echo json_encode([
    'msg' => 'Payment confirmed and MINEM credited',
    'order_id' => $orderId
]);